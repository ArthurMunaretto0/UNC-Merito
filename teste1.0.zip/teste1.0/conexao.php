<?php
$servername = "merito.mysql.dbaas.com.br"; // Nome do servidor
$username = "merito"; // Nome de usuário do MySQL
$password = "Merito123@"; // Senha do MySQL
$dbname = "merito"; // Nome do banco de dados

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Checa a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Determina a ação
if (isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action == 'register') {
        // Registro de usuário

        // Recebe os dados do formulário de registro
        $firstName = $_POST['firstName'] ?? null;
        $lastName = $_POST['lastName'] ?? null;
        $email = $_POST['email'] ?? null;
        $password = $_POST['password'] ?? null;
        $passwordConfirm = $_POST['passwordConfirm'] ?? null;

        // Verifica se as variáveis não são nulas
        if (is_null($firstName) || is_null($lastName) || is_null($email) || is_null($password) || is_null($passwordConfirm)) {
            die("Por favor, preencha todos os campos.");
        }

        // Verifica se as senhas correspondem
        if ($password !== $passwordConfirm) {
            die("As senhas não correspondem.");
        }

        // Verifica se o email já está registrado
        $sql = "SELECT * FROM usuarios WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            die("Este e-mail já está registrado.");
        }

        // Insere o novo usuário no banco de dados
        $sql = "INSERT INTO usuarios (email, senha, nome) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $email, $password, $firstName);
        if ($stmt->execute()) {
            echo "Conta criada com sucesso!";
            header("Location: login.html"); // Redireciona para a página de login
            exit();
        } else {
            echo "Erro: " . $stmt->error;
        }
    } elseif ($action == 'login') {
        // Login de usuário

        // Recebe os dados do formulário de login
        $email = $_POST['email'] ?? null;
        $password = $_POST['password'] ?? null;

        // Verifica se as variáveis não são nulas
        if (is_null($email) || is_null($password)) {
            die("Por favor, preencha todos os campos.");
        }

        // Busca o usuário no banco de dados
        $sql = "SELECT * FROM usuarios WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // Verifica se o usuário foi encontrado e se a senha está correta
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if ($password === $user['senha']) { // Sem verificar criptografia de senha
                echo "Login bem-sucedido!";
                header("Location: index.html"); // Redireciona para a página inicial
                exit();
            } else {
                echo "Senha inválida. Tente novamente.";
            }
        } else {
            echo "E-mail não encontrado. Tente novamente.";
        }
    } elseif ($action == 'add_paciente') {
        // Adicionar novo paciente

        // Recebe os dados do formulário de pacientes
        $nome = $_POST['nome'] ?? null;
        $cpf = $_POST['cpf'] ?? null;
        $data_nascimento = $_POST['data_nascimento'] ?? null;
        $contato = $_POST['contato'] ?? null;
        $ativo = $_POST['ativo'] ?? 1;

        // Verifica se as variáveis não são nulas
        if (is_null($nome) || is_null($cpf) || is_null($data_nascimento)) {
            die("Por favor, preencha todos os campos obrigatórios.");
        }

        // Verifica se o CPF já está registrado
        $sql = "SELECT * FROM pacientes WHERE cpf = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $cpf);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            die("Este CPF já está registrado.");
        }

        // Insere o novo paciente no banco de dados
        $sql = "INSERT INTO pacientes (nome, cpf, data_nascimento, contato, ativo) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $nome, $cpf, $data_nascimento, $contato, $ativo);
        if ($stmt->execute()) {
            echo "Paciente adicionado com sucesso!";
            header("Location: pacientes.html"); // Redireciona para a página de pacientes
            exit();
        } else {
            echo "Erro: " . $stmt->error;
        }
    } elseif ($action == 'list_pacientes') {
        // Listar pacientes

        $sql = "SELECT * FROM pacientes";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Exibe os dados em formato JSON (você pode ajustar para o formato necessário)
            $pacientes = [];
            while ($row = $result->fetch_assoc()) {
                $pacientes[] = $row;
            }
            echo json_encode($pacientes);
        } else {
            echo "Nenhum paciente encontrado.";
        }
    } elseif ($action == 'delete_paciente') {
        // Excluir paciente

        $id = $_POST['id'] ?? null;

        if (is_null($id)) {
            die("ID do paciente não fornecido.");
        }

        $sql = "DELETE FROM pacientes WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            echo "Paciente excluído com sucesso!";
            header("Location: pacientes.html"); // Redireciona para a página de pacientes
            exit();
        } else {
            echo "Erro: " . $stmt->error;
        }
    }
} else {
    die("Ação não especificada.");
}

// Fecha a conexão
$conn->close();
?>
